TabTune Converter v1.0
- Android app
- Converts individual notes to positions in preset tunings
- Converts simple 6-string fret patterns
- Includes E Standard, DADGAD, Drop D, D Standard, Drop C, Open G
- 'Find note' lists playable positions up to fret 24.

Build with Android Studio/Gradle:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Generate APK(s) > Build APK(s).
