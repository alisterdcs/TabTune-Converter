package com.example.tabtune

import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity

data class Tuning(val name:String, val strings:IntArray) // low -> high, MIDI note numbers

class MainActivity : AppCompatActivity() {
    private val tunings = listOf(
        Tuning("E Standard — E A D G B E", intArrayOf(40,45,50,55,59,64)),
        Tuning("DADGAD", intArrayOf(38,45,50,55,57,62)),
        Tuning("Drop D — D A D G B E", intArrayOf(38,45,50,55,59,64)),
        Tuning("D Standard — D G C F A D", intArrayOf(38,43,48,53,57,62)),
        Tuning("Drop C — C G C F A D", intArrayOf(36,43,48,53,57,62)),
        Tuning("Open G — D G D G B D", intArrayOf(38,43,50,55,59,62))
    )
    private lateinit var input: EditText
    private lateinit var from: Spinner
    private lateinit var to: Spinner
    private lateinit var result: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val layout = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(28,24,28,24)
            setBackgroundColor(Color.rgb(18,18,22))
        }
        fun label(s:String)=TextView(this).apply { text=s; textSize=16f; setTextColor(Color.WHITE); setPadding(0,12,0,6) }
        layout.addView(TextView(this).apply {
            text="🎸 TabTune Converter"; textSize=26f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(0,8,0,18)
        })
        layout.addView(label("Nota / TAB"))
        input=EditText(this).apply { hint="Ex.: E, F# ou 0-2-2-0-0-0"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); minLines=2 }
        layout.addView(input)
        layout.addView(label("Afinação original"))
        from=Spinner(this); layout.addView(from)
        layout.addView(label("Converter para"))
        to=Spinner(this); layout.addView(to)
        val names=tunings.map{it.name}
        val adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,names)
        from.adapter=adapter; to.adapter=adapter; to.setSelection(1)

        val btn=Button(this).apply { text="CONVERTER AGORA" }
        layout.addView(btn)
        val find=Button(this).apply { text="🔎 Encontrar a nota na nova afinação" }
        layout.addView(find)
        result=TextView(this).apply { textSize=17f; setTextColor(Color.WHITE); setPadding(0,18,0,0) }
        layout.addView(result)

        btn.setOnClickListener { convert(false) }
        find.setOnClickListener { convert(true) }
        setContentView(layout)
    }

    private fun noteToMidi(s:String):Int? {
        val m=Regex("""^([A-Ga-g])([#b]?)(-?\d+)?$""").matchEntire(s.trim()) ?: return null
        val base=mapOf('C' to 0,'D' to 2,'E' to 4,'F' to 5,'G' to 7,'A' to 9,'B' to 11)[m.groupValues[1].uppercase()[0]]!!
        val acc=when(m.groupValues[2]){"#"->1;"b"->-1;else->0}
        val oct=m.groupValues[3].ifEmpty{"4"}.toInt()
        return 12*(oct+1)+base+acc
    }
    private fun midiName(n:Int):String {
        val names=arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        return names[(n%12+12)%12]+((n/12)-1)
    }
    private fun convert(findOnly:Boolean) {
        val text=input.text.toString().trim()
        val target=tunings[to.selectedItemPosition]
        val note=noteToMidi(text)
        if(findOnly && note!=null) {
            val hits=target.strings.mapIndexedNotNull{idx,open ->
                val fret=note-open
                if(fret in 0..24) "corda ${idx+1}: casa $fret" else null
            }
            result.text=if(hits.isEmpty()) "Não encontrei essa nota nas primeiras 24 casas." else
                "${midiName(note)} em ${target.name}:\n"+hits.joinToString("\n")
            return
        }
        if(note!=null) {
            val hits=target.strings.mapIndexedNotNull{idx,open ->
                val fret=note-open
                if(fret in 0..24) "Corda ${idx+1} — casa $fret" else null
            }
            result.text="Nota ${midiName(note)} → ${target.name}\n\n"+hits.joinToString("\n")
            return
        }
        val parts=text.split(Regex("\\s+")).filter{it.isNotEmpty()}
        if(parts.size>=6 && parts.all{it.matches(Regex("\\d+|x|X"))}) {
            val src=tunings[from.selectedItemPosition]
            val out=parts.mapIndexed { i,p ->
                if(p.equals("x",true)) "x" else {
                    val midi=src.strings.getOrElse(i){0}+p.toInt()
                    val choices=target.strings.mapIndexedNotNull{j,o ->
                        val f=midi-o; if(f in 0..24) Pair(f,j+1) else null
                    }
                    choices.minByOrNull{it.first}?.first?.toString() ?: "?"
                }
            }
            result.text="TAB convertida:\n"+out.joinToString("-")+"\n\nObs.: para TABs completas com ritmo/hammer-on/slide, use o formato Guitar Pro/AlphaTex em uma futura versão."
        } else result.text="Digite uma nota (ex.: F#) ou seis casas (ex.: 0-2-2-0-0-0)."
    }
}
